/*20150923
 * Typedef of tmdff
 */

#ifndef _tmdff_h
#define _tmdff_h

#include "typedefs.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct
{
    real f;
    int idx;
} PAIR;

typedef struct
{
 gmx_bool bTMDFF;
 int nat,ncg;//Total Nr. of atoms and feature points
 int ncgr;   // number of elements in distance matrix,Rij
 int bk[8];
 real rms,enerms,rms1,pdev,rms2;
 real *rmsarray;
 real k,inirms,endrms;//Force constant of tmdff
 //real scut,mcut,lcut;
 //real sfc,mfc,lfc;
 //int nenm,nm_l,nm_u;
 int seed;
 int tmdfrq; //freq. to update TMDFF
 int ioutF;//print out Force in log for testing
 int *cgn;//index of feature point of each atom
 int *cgntmp;//index of feature point of each atom
 int *resid;
 int nbb,*bb;
 //int **globidx;//index of atoms in each feature points
 rvec *xf,*xr,hbox;//atomic coordinates
 rvec *xcg;//feature point coordinates
 rvec *xcg1;//feature point coordinates
 rvec *xcg0;//feature point coordinates
 rvec *xcg2;//feature point coordinates
 //rvec **enmvec;
 //double *pdf,*pdf0;
 real *r0;
 real *cgr;//All Rij in the distance matrix
 real *cgr1;//All Rij for the rigid parts 
 real *cgr0;//The target Rij0 for the rigid parts
 double *ma,*mcg;//atomic and glob masses
 matrix box_glb;
} t_tmdff;

extern char *fgets2(char *s, int n, FILE *stream);

static inline void oprod(rvec a,rvec b,rvec c)
{
  c[XX]=a[YY]*b[ZZ]-a[ZZ]*b[YY];
  c[YY]=a[ZZ]*b[XX]-a[XX]*b[ZZ];
  c[ZZ]=a[XX]*b[YY]-a[YY]*b[XX];
}

static inline void clear_matm(matrix a)
{
  a[XX][XX]=a[XX][YY]=a[XX][ZZ]=0.0;
  a[YY][XX]=a[YY][YY]=a[YY][ZZ]=0.0;
  a[ZZ][XX]=a[ZZ][YY]=a[ZZ][ZZ]=0.0;
}

void error_memory_allocation(int , char *);
void error_open_filename(int error_number, char *program, char *argv);

static double calc_max (double *phi, unsigned long nvox);
static double calc_min (double *phi, unsigned long nvox);
static int binary_search(double key, double *x, int nx);

static real sumvec(rvec *x, int n);
/* open and read the parameters (.tmi)*/
static void read_tmi(const char *tminam, t_tmdff *tmd, FILE *log);

//void clust_cg(t_state *state, t_tmdff *tmd, t_commrec *cr, t_mdatoms *md, gmx_mtop_t *mtop, rvec *tar_f, gmx_large_int_t step, t_inputrec *ir, FILE *log);
void clust_cg(rvec *statex, t_tmdff *tmd, t_commrec *cr, t_mdatoms *md, gmx_mtop_t *mtop, rvec *tar_f, gmx_large_int_t step, t_inputrec *ir, FILE *log);

void write_tmo(t_tmdff *tmd);

void init_tmdff(t_inputrec *ir, t_commrec *cr, const char *tminam,
                t_tmdff *tmd, t_state *global_state, FILE *log);

void update_sim_force(t_commrec *cr, rvec *tmd_f, rvec *f, t_mdatoms *md, gmx_mtop_t *mtop);

#ifdef __cplusplus
}
#endif

#endif 
