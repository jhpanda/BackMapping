/* header file for lib_rnd.c */
void sgenrand (unsigned long); 
double genrand ();
